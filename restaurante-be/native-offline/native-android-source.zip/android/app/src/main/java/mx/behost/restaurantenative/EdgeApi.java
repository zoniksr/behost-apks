package mx.behost.restaurantenative;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** HTTPS-only transport. No trust-all certificates and no WebView. */
public final class EdgeApi {
  private final String base;
  private final String token;
  public EdgeApi(String url,String bearer){
    if(url==null||!url.startsWith("https://")||url.contains("@")||url.contains("#")||url.contains("?"))throw new IllegalArgumentException("Solo HTTPS y un servidor explícito");
    base=url.replaceAll("/+$","");token=bearer;
    if(token==null||token.length()<36)throw new IllegalArgumentException("Vincula primero un dispositivo autorizado");
  }
  private JSONObject request(String path,JSONObject value) throws Exception {
    URL url=new URL(base+path);
    if(!url.getProtocol().equals("https"))throw new IllegalArgumentException("Protocolo inseguro");
    HttpURLConnection c=(HttpURLConnection)url.openConnection();
    try {
      c.setConnectTimeout(5500);c.setReadTimeout(7500);c.setUseCaches(false);c.setInstanceFollowRedirects(false);
      c.setRequestProperty("Authorization","Bearer "+token);c.setRequestProperty("Accept","application/json");
      if(value!=null){c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");
        byte[] body=value.toString().getBytes(StandardCharsets.UTF_8);
        if(body.length>32000)throw new IllegalArgumentException("Solicitud demasiado grande");
        try(OutputStream stream=c.getOutputStream()){stream.write(body);}
      }
      int status=c.getResponseCode();
      if(status>=300&&status<400)throw new IllegalStateException("Redirección no permitida");
      try(InputStream stream=status<400?c.getInputStream():c.getErrorStream()){
        if(stream==null)throw new IllegalStateException("Sin respuesta del servidor");
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] bytes=new byte[4096];int read;
        while((read=stream.read(bytes))!=-1){out.write(bytes,0,read);if(out.size()>300000)throw new IllegalStateException("Respuesta excesiva");}
        JSONObject response=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
        if(status>=400||!response.optBoolean("ok",false))throw new IllegalStateException(response.optString("error","Error de servidor ("+status+")"));
        return response;
      }
    }finally{c.disconnect();}
  }
  public JSONObject snapshot() throws Exception {return request("/v1/snapshot",null);}
  public JSONObject mutate(JSONObject action) throws Exception {return request("/v1/mutate",action);}
}
