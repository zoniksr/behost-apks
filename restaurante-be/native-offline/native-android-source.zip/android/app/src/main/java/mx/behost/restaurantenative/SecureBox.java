package mx.behost.restaurantenative;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Android Keystore AES/GCM, random IV, authenticated encrypted local records. */
public final class SecureBox {
  private static final String ALIAS="restaurante_be_native_pilot_aes_v1";
  private final SharedPreferences prefs;
  public SecureBox(Context ctx){prefs=ctx.getSharedPreferences("connection_private",Context.MODE_PRIVATE);}
  private SecretKey key() throws Exception {
    KeyStore s=KeyStore.getInstance("AndroidKeyStore");s.load(null);
    if(!s.containsAlias(ALIAS)){
      KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
      g.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256).setRandomizedEncryptionRequired(true).build());g.generateKey();
    }
    return (SecretKey)s.getKey(ALIAS,null);
  }
  public String seal(String plain) throws Exception {
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());
    byte[] iv=c.getIV(),payload=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));
    byte[] joined=new byte[iv.length+payload.length];System.arraycopy(iv,0,joined,0,iv.length);
    System.arraycopy(payload,0,joined,iv.length,payload.length);
    return Base64.encodeToString(joined,Base64.NO_WRAP);
  }
  public String open(String encrypted) throws Exception {
    byte[] src=Base64.decode(encrypted,Base64.NO_WRAP);
    if(src.length<29)throw new IllegalArgumentException("Registro cifrado inválido");
    Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,src,0,12));
    return new String(c.doFinal(src,12,src.length-12),StandardCharsets.UTF_8);
  }
  public void storeToken(String token) throws Exception {if(token==null||token.isEmpty())prefs.edit().remove("token").apply();else prefs.edit().putString("token",seal(token)).apply();}
  public String token(){try{return open(prefs.getString("token",""));}catch(Exception ignored){return "";}}
  public void clear(){prefs.edit().remove("token").apply();}
}
