package mx.behost.restaurantenative;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.io.IOException;
import javax.net.ssl.SSLException;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Four real Android Views-based role UIs. No WebView and no embedded HTML.
 *  PIlot LAN edge only, not an approved cloud POS or completed fiscal system.
 */
public final class MainActivity extends Activity {
  private static final int BG=Color.rgb(244,248,254),WHITE=Color.WHITE,INK=Color.rgb(27,45,76),MUTED=Color.rgb(93,112,143),BLUE=Color.rgb(35,102,232),GREEN=Color.rgb(20,141,111),AMBER=Color.rgb(187,113,16);
  private final ExecutorService queue=Executors.newSingleThreadExecutor();
  private SecureBox secure;private NativeStore store;private SharedPreferences prefs;
  private LinearLayout root,content;private TextView status,subTitle;private JSONObject snapshot;
  private final String role=BuildConfig.ROLE;
  private boolean loading=false,online=false;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(22,48,87));getWindow().setNavigationBarColor(BG);
    secure=new SecureBox(this);store=new NativeStore(this,secure);prefs=getSharedPreferences("edge_local_settings",MODE_PRIVATE);
    buildRoot();snapshot=store.lastSnapshot(role);render();if(connectionReady())reload();
  }
  @Override public void onDestroy(){queue.shutdownNow();store.close();super.onDestroy();}
  private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
  private GradientDrawable shape(int color,int stroke,int corner){GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{color,color});bg.setCornerRadius(dp(corner));if(stroke!=0)bg.setStroke(dp(1),stroke);return bg;}
  private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
  private TextView text(String value,int size,boolean bold,int color){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
    if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setIncludeFontPadding(true);return t;}
  private void pad(View v,int a,int b){v.setPadding(dp(a),dp(b),dp(a),dp(b));}
  private LinearLayout card(){LinearLayout l=column();l.setBackground(shape(WHITE,Color.rgb(222,232,245),19));pad(l,16,13);l.setElevation(dp(3));return l;}
  private Button button(String label,boolean primary){Button b=new Button(this);b.setAllCaps(false);b.setText(label);b.setTextSize(14);b.setMinHeight(dp(50));b.setTextColor(primary?WHITE:BLUE);b.setBackground(shape(primary?BLUE:Color.rgb(235,244,255),primary?BLUE:Color.rgb(205,225,255),13));return b;}
  private LinearLayout.LayoutParams lp(int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);return p;}
  private void buildRoot(){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);root=column();root.setPadding(dp(14),dp(18),dp(14),dp(30));scroll.addView(root);setContentView(scroll);
    LinearLayout hero=card();hero.setBackground(shape(Color.rgb(25,53,102),0,23));hero.setElevation(dp(7));
    TextView brand=text("✦  Restaurante Be · NATIVO",11,true,Color.rgb(177,215,255));hero.addView(brand);
    String icon=role.equals("mesero")?"🍽️":role.equals("cocina")?"👨‍🍳":role.equals("host")?"🪑":"🚘";
    String name=role.equals("mesero")?"Mesero":role.equals("cocina")?"Cocina":role.equals("host")?"Hostess":"Valet";
    hero.addView(text(icon+"  "+name,29,true,WHITE),lp(8));hero.addView(text("Piloto Android real · datos compartidos por servidor local",12,false,Color.rgb(212,228,249)),lp(6));root.addView(hero);
    LinearLayout controls=card();root.addView(controls,lp(13));status=text("● Sin vincular",15,true,AMBER);controls.addView(status);
    subTitle=text("Sin conexión, sólo hay borradores locales",12,false,MUTED);controls.addView(subTitle,lp(4));
    LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);controls.addView(actions,lp(10));
    Button refresh=button("↻ Actualizar",true),settings=button("⚙ Configurar",false);
    LinearLayout.LayoutParams each=new LinearLayout.LayoutParams(0,dp(50),1);each.rightMargin=dp(7);actions.addView(refresh,each);actions.addView(settings,new LinearLayout.LayoutParams(0,dp(50),1));
    refresh.setOnClickListener(v->reload());settings.setOnClickListener(v->settings());
    content=column();root.addView(content,lp(14));
  }
  private boolean connectionReady(){return prefs.getString("url","").startsWith("https://")&&secure.token().length()>=36;}
  private EdgeApi api(){return new EdgeApi(prefs.getString("url",""),secure.token());}
  private void setStatus(String label,boolean connected){online=connected;status.setText((connected?"● ":"◌ ")+label);status.setTextColor(connected?GREEN:AMBER);
    subTitle.setText(connected?"Servidor de restaurante por Wi-Fi · No requiere Internet si la LAN funciona":"Sin servidor local · las acciones quedan en BORRADOR, nunca confirmadas");}
  private void settings(){LinearLayout layout=column();pad(layout,18,6);
    EditText url=new EditText(this);url.setHint("https://edge.turestaurante.local:8443");url.setSingleLine(true);url.setText(prefs.getString("url",""));layout.addView(text("Servidor HTTPS local",14,true,INK));layout.addView(url,lp(3));
    EditText token=new EditText(this);token.setHint("Código de vinculación entregado por Administración");token.setSingleLine(true);token.setInputType(129);layout.addView(text("Token de dispositivo",14,true,INK),lp(12));layout.addView(token);
    layout.addView(text("La red local exige certificado confiable. No aceptamos HTTP ni certificados desconocidos. No pegues contraseñas del hosting.",12,false,MUTED),lp(10));
    new AlertDialog.Builder(this).setTitle("Vincular aplicación nativa").setView(layout).setNegativeButton("Cancelar",null)
      .setNeutralButton("Desvincular",(d,w)->{secure.clear();store.clearAll();snapshot=null;prefs.edit().remove("url").apply();setStatus("Desvinculado",false);render();})
      .setPositiveButton("Guardar",(d,w)->{
        String endpoint=url.getText().toString().trim().replaceAll("/+$","");String bearer=token.getText().toString().trim();
        try{if(!endpoint.startsWith("https://")||endpoint.contains("@"))throw new IllegalArgumentException("Se requiere HTTPS");
          if(!endpoint.equals(prefs.getString("url",""))||!bearer.isEmpty()){store.clearAll();snapshot=null;}
          prefs.edit().putString("url",endpoint).apply();if(!bearer.isEmpty())secure.storeToken(bearer);
          if(!connectionReady())throw new IllegalArgumentException("Falta token válido");reload();
        }catch(Exception e){toast("Vinculación no válida: "+e.getMessage());}
      }).show();
  }
  private void reload(){if(loading)return;if(!connectionReady()){setStatus("Sin vincular",false);settings();return;}
    loading=true;setStatus("Conectando al servidor local…",false);
    queue.execute(()->{try{JSONObject data=api().snapshot();store.saveSnapshot(role,data);runOnUiThread(()->{snapshot=data;loading=false;setStatus("Wi-Fi / servidor local conectado",true);render();});}
      catch(Exception ex){runOnUiThread(()->{loading=false;setStatus("Sin servidor local",false);render();toast("Mostrando datos guardados. "+ex.getMessage());});}});
  }
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
  private void heading(String title,String helper){TextView h=text(title,21,true,INK);content.addView(h,lp(14));content.addView(text(helper,12,false,MUTED),lp(5));}
  private String stateName(String s){if(s.equals("libre"))return "Lista";if(s.equals("ocupada"))return "Ocupada";if(s.equals("limpieza"))return "Por limpiar";return s;}
  private void render(){content.removeAllViews();if(snapshot==null){heading("Aún no hay información", "Conecta una vez para guardar una vista cifrada de este restaurante.");}
    else{
      if(role.equals("cocina"))renderKitchen();else if(role.equals("valet"))renderValet();else renderTables();
    }
    renderDrafts();
  }
  private void addCard(LinearLayout card){content.addView(card,lp(10));card.setAlpha(0f);card.setTranslationY(dp(8));card.animate().alpha(1f).translationY(0f).setDuration(150).start();}
  private void renderTables(){heading(role.equals("host")?"Recepción · plano de mesas":"Mis mesas y comandas", "Una mesa ocupada sólo se confirma desde el servidor local.");
    JSONArray tables=snapshot.optJSONArray("tables");if(tables==null)return;
    final String self=snapshot.optString("actor_id","");
    for(int i=0;i<tables.length();i++){JSONObject table=tables.optJSONObject(i);if(table==null)continue;
      if(role.equals("mesero")&&!self.equals(table.optString("waiter_id")))continue;
      LinearLayout c=card();String s=table.optString("status","libre");int color=s.equals("libre")?GREEN:s.equals("ocupada")?BLUE:AMBER;
      TextView name=text("🪑  "+table.optString("label")+"     "+stateName(s),18,true,INK);c.addView(name);
      c.addView(text(table.optString("area","")+"   ·   "+table.optInt("seats")+" lugares   ·   "+table.optInt("guests",0)+" sentados",12,false,MUTED),lp(5));
      if(!table.isNull("waiter_id")&&!table.optString("waiter_id","").isEmpty())c.addView(text("👤 Responsable: "+table.optString("waiter_id"),12,true,color),lp(5));
      if(role.equals("host")){
        if(s.equals("libre"))addAction(c,"✅ Recibir clientes",()->seat(table));
        if(s.equals("ocupada")){addAction(c,"🔄 Relevar mesero",()->handoff(table));addAction(c,"↗ Cambiar de mesa",()->move(table));}
      }else if(s.equals("ocupada"))addAction(c,"＋ Agregar a comanda",()->order(table));
      addCard(c);
    }
  }
  private void renderKitchen(){heading("🔥 Comandas en preparación", "Pendiente → Preparando → Lista. Los cambios requieren confirmación de servidor local.");
    JSONArray items=snapshot.optJSONArray("items");if(items==null||items.length()==0){content.addView(text("No hay comandas pendientes",15,false,MUTED),lp(16));return;}
    for(int i=0;i<items.length();i++){JSONObject it=items.optJSONObject(i);if(it==null)continue;
      LinearLayout c=card();c.addView(text("🍳 "+it.optString("label"),19,true,INK));
      c.addView(text("Mesa "+it.optString("table_id")+" · "+it.optInt("quantity")+" unidades · "+it.optString("status"),13,false,MUTED),lp(6));
      String next=it.optString("status").equals("pendiente")?"preparando":it.optString("status").equals("preparando")?"listo":"";
      if(!next.isEmpty())addAction(c,next.equals("preparando")?"👨‍🍳 Comenzar":"✅ Marcar listo",()->send("kitchen_status",obj("item_id",it.optString("id"),"revision",it.optInt("revision"),"status",next)));
      addCard(c);
    }
  }
  private void renderValet(){heading("🚘 Valet · vehículos", "Placas, ficha y estado del automóvil. Entrega exige confirmación.");
    Button add=button("＋ Recibir vehículo",true);content.addView(add,lp(12));add.setOnClickListener(v->newValet());
    JSONArray cars=snapshot.optJSONArray("valet");if(cars==null)return;
    for(int i=0;i<cars.length();i++){JSONObject it=cars.optJSONObject(i);if(it==null)continue;
      LinearLayout c=card();c.addView(text("🚗  "+it.optString("plate"),20,true,INK));c.addView(text(it.optString("color")+" · "+it.optString("status"),13,false,MUTED),lp(6));
      String now=it.optString("status");String next=now.equals("estacionado")?"solicitado":now.equals("solicitado")?"en_camino":now.equals("en_camino")?"listo":now.equals("listo")?"entregado":"";
      if(!next.isEmpty())addAction(c,next.equals("entregado")?"🔑 Confirmar entrega":"↗ "+next,()->{
        if(next.equals("entregado"))new AlertDialog.Builder(this).setTitle("¿Verificaste placa y ficha?").setMessage("Confirma físicamente la identidad antes de entregar el auto.")
          .setNegativeButton("Cancelar",null).setPositiveButton("Entregar",(d,w)->send("valet_status",obj("id",it.optString("id"),"revision",it.optInt("revision"),"status",next,"delivery_confirmed",true))).show();
        else send("valet_status",obj("id",it.optString("id"),"revision",it.optInt("revision"),"status",next));
      });addCard(c);
    }
  }
  private void addAction(LinearLayout card,String text,Runnable action){Button button=button(text,false);card.addView(button,lp(10));button.setOnClickListener(v->action.run());}
  private JSONObject obj(Object... pairs){JSONObject o=new JSONObject();try{for(int i=0;i+1<pairs.length;i+=2)o.put((String)pairs[i],pairs[i+1]);}catch(Exception ignored){}return o;}
  private EditText edit(String hint,String value){EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setHint(hint);e.setTextSize(16);return e;}
  private LinearLayout dialogBody(){LinearLayout c=column();pad(c,20,10);return c;}
  private JSONArray staff(){return snapshot!=null?snapshot.optJSONArray("staff"):null;}
  private String[] staffLabels(){JSONArray s=staff();if(s==null)return new String[0];String[] out=new String[s.length()];for(int i=0;i<s.length();i++){JSONObject it=s.optJSONObject(i);out[i]=it.optString("display_name")+" ("+it.optString("id")+")";}return out;}
  private String waiterId(int index){JSONArray s=staff();JSONObject it=s!=null?s.optJSONObject(index):null;return it==null?"":it.optString("id");}
  private void seat(JSONObject table){LinearLayout form=dialogBody();EditText guests=edit("Personas","2");guests.setInputType(2);form.addView(text("Número de personas",13,true,INK));form.addView(guests);
    String[] names=staffLabels();if(names.length==0){toast("No hay meseros disponibles en esta vista");return;}
    Spinner waiter=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);waiter.setAdapter(adapter);
    form.addView(text("Mesero responsable",13,true,INK),lp(12));form.addView(waiter);
    new AlertDialog.Builder(this).setTitle("🪑 "+table.optString("label")).setView(form).setNegativeButton("Volver",null)
      .setPositiveButton("Asignar",(d,w)->{
        try{send("table_seat",obj("table_id",table.optString("id"),"guests",Integer.parseInt(guests.getText().toString()),"waiter_id",waiterId(waiter.getSelectedItemPosition()),"revision",table.optInt("revision")));}
        catch(NumberFormatException e){toast("Cantidad inválida");}
      }).show();}
  private void handoff(JSONObject table){String[] labels=staffLabels();if(labels.length==0){toast("No hay personal vinculado");return;}
    LinearLayout form=dialogBody();Spinner staff=new Spinner(this);staff.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));form.addView(staff);
    EditText reason=edit("Motivo del relevo","");form.addView(reason,lp(9));
    new AlertDialog.Builder(this).setTitle("🔄 Relevar responsable").setView(form).setNegativeButton("Cancelar",null).setPositiveButton("Confirmar",(d,w)->send("waiter_handoff",obj("table_id",table.optString("id"),"waiter_id",waiterId(staff.getSelectedItemPosition()),"reason",reason.getText().toString(),"revision",table.optInt("revision")))).show();}
  private void move(JSONObject table){JSONArray tables=snapshot.optJSONArray("tables");if(tables==null)return;
    java.util.ArrayList<JSONObject> free=new java.util.ArrayList<>();java.util.ArrayList<String> names=new java.util.ArrayList<>();
    for(int i=0;i<tables.length();i++){JSONObject t=tables.optJSONObject(i);if(t!=null&&t.optString("status").equals("libre")){free.add(t);names.add(t.optString("label"));}}
    if(free.isEmpty()){toast("No hay mesas libres");return;}
    LinearLayout form=dialogBody();Spinner target=new Spinner(this);target.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));form.addView(target);
    EditText reason=edit("Razón del traslado","");form.addView(reason,lp(8));
    new AlertDialog.Builder(this).setTitle("↗ Cambiar mesa").setView(form).setNegativeButton("Volver",null)
      .setPositiveButton("Mover visita y cuenta",(d,w)->{
        JSONObject to=free.get(target.getSelectedItemPosition());send("table_move",obj("table_id",table.optString("id"),"target_table_id",to.optString("id"),
           "revision",table.optInt("revision"),"target_revision",to.optInt("revision"),"reason",reason.getText().toString()));
      }).show();}
  private void order(JSONObject table){JSONArray menu=snapshot.optJSONArray("menu");if(menu==null||menu.length()==0){toast("Catálogo aún no cargado");return;}
    String[] choices=new String[menu.length()];for(int i=0;i<menu.length();i++){JSONObject m=menu.optJSONObject(i);choices[i]=m.optString("label")+" · $"+String.format(java.util.Locale.forLanguageTag("es-MX"),"%.2f",m.optInt("price_cents")/100.0);}
    LinearLayout form=dialogBody();Spinner sel=new Spinner(this);sel.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices));form.addView(sel);
    EditText qty=edit("Cantidad","1");qty.setInputType(2);form.addView(qty,lp(8));
    new AlertDialog.Builder(this).setTitle("🍽️ Nueva comanda").setView(form).setNegativeButton("Cancelar",null)
      .setPositiveButton("Enviar",(d,w)->{
        try{JSONObject p=menu.optJSONObject(sel.getSelectedItemPosition());send("order_add",obj("table_id",table.optString("id"),"product_id",p.optString("id"),"qty",Integer.parseInt(qty.getText().toString()),"visit_id",table.optString("visit_id"),"revision",table.optInt("revision")));}
        catch(Exception ex){toast("Revisa la cantidad");}
      }).show();}
  private void newValet(){LinearLayout form=dialogBody();EditText plate=edit("Placas","");form.addView(plate);EditText color=edit("Color","");form.addView(color,lp(8));
    new AlertDialog.Builder(this).setTitle("🚘 Recibir auto").setView(form).setNegativeButton("Cancelar",null)
      .setPositiveButton("Recibir",(d,w)->send("valet_create",obj("plate",plate.getText().toString().trim(),"color",color.getText().toString().trim()))).show();}
  private void send(String action,JSONObject payload){String eid=UUID.randomUUID().toString();JSONObject entry=obj("event_id",eid,"action",action,"payload",payload);
    if(!connectionReady()){saveDraft(entry);return;}
    queue.execute(()->{try{api().mutate(entry);runOnUiThread(()->{toast("✅ Operación confirmada por servidor local");reload();});}
      catch(SSLException security){runOnUiThread(()->toast("Certificado inválido. No se envió ni puso en cola."));}
      catch(ConnectException|UnknownHostException|SocketTimeoutException offline){runOnUiThread(()->saveDraft(entry));}
      catch(IOException network){runOnUiThread(()->saveDraft(entry));}
      catch(Exception error){runOnUiThread(()->toast("No se aplicó: "+error.getMessage()+". Actualiza antes de reintentar."));}});
  }
  private void saveDraft(JSONObject entry){try{store.saveDraft(entry.optString("event_id"),role,entry);setStatus("Borrador local · pendiente",false);render();toast("⚠️ Guardado cifrado. NO enviado a Cocina/Caja. Reconciliar cuando vuelva el servidor local.");}
    catch(Exception e){toast("No se pudo guardar: "+e.getMessage());}}
  private void renderDrafts(){int n=store.draftCount(role);heading("🗃️ Pendientes locales · "+n,"Nunca se envían automáticamente al detectar Internet. Cada reintento requiere confirmación.");
    JSONArray drafts=store.drafts(role);for(int i=0;i<drafts.length();i++){JSONObject e=drafts.optJSONObject(i);if(e==null)continue;
      LinearLayout card=card();card.addView(text("⚠️ "+e.optString("action"),15,true,AMBER));card.addView(text("BORRADOR · "+e.optString("event_id").substring(0,8),11,false,MUTED),lp(5));
      addAction(card,"↻ Verificar y enviar",()->new AlertDialog.Builder(this).setTitle("Reconciliar borrador").setMessage("Puede haberse aplicado antes de perder conexión. Se reutilizará el mismo ID para impedir duplicados. Si el servidor rechaza por estado desactualizado, revisa manualmente.")
         .setNegativeButton("Cancelar",null).setPositiveButton("Reintentar",(d,w)->retry(e)).show());
      addAction(card,"Descartar (con confirmación)",()->new AlertDialog.Builder(this).setTitle("Descartar borrador").setMessage("Esta acción no elimina ningún pedido ya recibido en el servidor.")
         .setNegativeButton("Volver",null).setPositiveButton("Descartar",(d,w)->{store.removeDraft(e.optString("event_id"));render();}).show());
      addCard(card);
    }
  }
  private void retry(JSONObject entry){if(!connectionReady()){toast("Vincula el servidor local primero");return;}
    queue.execute(()->{try{JSONObject response=api().mutate(entry);runOnUiThread(()->{store.removeDraft(entry.optString("event_id"));toast(response.optBoolean("replayed")?"✅ Ya había sido aplicada. No se duplicó.":"✅ Aceptada por servidor local");reload();});}
      catch(Exception ex){runOnUiThread(()->toast("Conservado para revisión: "+ex.getMessage()));}});
  }
}
