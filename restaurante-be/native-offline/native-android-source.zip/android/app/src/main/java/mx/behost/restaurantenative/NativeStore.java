package mx.behost.restaurantenative;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.JSONArray;
import org.json.JSONObject;

/** Encrypted snapshots and durable drafts. Drafts are never auto-posted after isolation. */
public final class NativeStore extends SQLiteOpenHelper {
  private final SecureBox crypto;
  public NativeStore(Context c, SecureBox secure){super(c,"rb-native-pilot.db",null,1);crypto=secure;}
  @Override public void onCreate(SQLiteDatabase db){
    db.execSQL("CREATE TABLE snapshot(role TEXT PRIMARY KEY,encrypted_json TEXT NOT NULL,created_at INTEGER NOT NULL)");
    db.execSQL("CREATE TABLE drafts(event_id TEXT PRIMARY KEY,role TEXT NOT NULL,encrypted_json TEXT NOT NULL,created_at INTEGER NOT NULL)");
  }
  @Override public void onUpgrade(SQLiteDatabase db,int old,int current){throw new IllegalStateException("No hay migración destructiva autorizada");}
  public void saveSnapshot(String role,JSONObject json) throws Exception {
    ContentValues data=new ContentValues();data.put("role",role);data.put("encrypted_json",crypto.seal(json.toString()));data.put("created_at",System.currentTimeMillis());
    getWritableDatabase().insertWithOnConflict("snapshot",null,data,SQLiteDatabase.CONFLICT_REPLACE);
  }
  public JSONObject lastSnapshot(String role){
    try(Cursor rows=getReadableDatabase().rawQuery("SELECT encrypted_json FROM snapshot WHERE role=?",new String[]{role})){
      if(rows.moveToFirst())return new JSONObject(crypto.open(rows.getString(0)));
    }catch(Exception ignored){}return null;
  }
  public void saveDraft(String eventId,String role,JSONObject json) throws Exception {
    ContentValues data=new ContentValues();data.put("event_id",eventId);data.put("role",role);data.put("encrypted_json",crypto.seal(json.toString()));data.put("created_at",System.currentTimeMillis());
    getWritableDatabase().insertWithOnConflict("drafts",null,data,SQLiteDatabase.CONFLICT_ABORT);
  }
  public JSONArray drafts(String role){
    JSONArray out=new JSONArray();
    try(Cursor c=getReadableDatabase().rawQuery("SELECT event_id,encrypted_json FROM drafts WHERE role=? ORDER BY created_at",new String[]{role})){
      while(c.moveToNext()){
        JSONObject entry=new JSONObject(crypto.open(c.getString(1)));entry.put("event_id",c.getString(0));out.put(entry);
      }
    }catch(Exception ignored){}return out;
  }
  public void clearAll(){SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{
    db.delete("drafts",null,null);db.delete("snapshot",null,null);db.setTransactionSuccessful();
  }finally{db.endTransaction();}}
  public void removeDraft(String eventId){getWritableDatabase().delete("drafts","event_id=?",new String[]{eventId});}
  public int draftCount(String role){try(Cursor c=getReadableDatabase().rawQuery("SELECT count(*) FROM drafts WHERE role=?",new String[]{role})){
    if(c.moveToFirst())return c.getInt(0);
  }return 0;}
}
